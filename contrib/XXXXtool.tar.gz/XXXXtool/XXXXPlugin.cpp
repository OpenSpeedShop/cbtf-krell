#include <boost/bind.hpp>
#include <typeinfo>
#include <iostream>
#include <stdio.h>
#include <sys/param.h>
#include <string>
#include <vector>

#include <KrellInstitute/CBTF/Component.hpp>
#include <KrellInstitute/CBTF/Type.hpp>
#include <KrellInstitute/CBTF/Version.hpp>

using namespace KrellInstitute::CBTF;

/**
 *  * Component type used by the unit test for the Component class.
 *   */
class __attribute__ ((visibility ("hidden"))) XXXXPlugin :
    public Component
{

public:
    /** Factory function for this component type. */
    static Component::Instance factoryFunction()
    {
        return Component::Instance(
          reinterpret_cast<Component*>(new XXXXPlugin())
        );
    }

private:
    /** Default constructor. */
    XXXXPlugin() :
        Component(Type(typeid(XXXXPlugin)), Version(1, 0, 0))
    {
        declareInput<std::string>(
            "in", boost::bind(&XXXXPlugin::inHandler, this, _1)
            );
        declareOutput<std::string>("out");
    }

    /** Handler for the "in" input.*/
    void inHandler(const std::string& in)
    { 

      /*** write your component body here ***/

      /*** change the output ***/
      std::string output = in;

      emitOutput<std::string>("out", output ); 
    }
}; // end class XXXXPlugin

KRELL_INSTITUTE_CBTF_REGISTER_FACTORY_FUNCTION(XXXXPlugin)

