#! /bin/csh

if ( $2 == "" ) then
  echo "*** Error must run setXXXX.sh with 2 args"
  echo "    arg 1 is the name of the tool"
  echo "    arg 2 is the path to cbtf root"
  echo "    For example: setXXXX.sh test /usr/projects/packages/mmason/opt/cbtf-rr"
else
  # setup the vars
  set mypwd = `pwd | sed -e s/"\/"/"\\\/"/g`
  set cbtfpwd = `echo "$2" | sed -e s/"\/"/"\\\/"/g`

  if ( -e "myconfigXXXX" ) then
    echo ""
    echo "sed -e s/XXTOOL-PATHXX/"$mypwd"/g -e s/XXCBTFXX/"$cbtfpwd"/g myconfigXXXX > myconfig"
    sed -e s/XXTOOL-PATHXX/"$mypwd"/g -e s/XXCBTFXX/"$cbtfpwd"/g myconfigXXXX > myconfig
    rm myconfigXXXX
  else
    echo "*** error can't find myconfigXXXX"
  endif

  if ( -e "MakefileXXXX.am" ) then
    echo ""
    echo "sed -e s/XXXX/$1/g MakefileXXXX.am > Makefile.am"
    sed -e s/XXXX/$1/g MakefileXXXX.am > Makefile.am
    rm MakefileXXXX.am
  else
    echo "*** error can't find MakefileXXXX.am"
  endif

  if ( -e "XXXX_tool.cpp" ) then
    echo ""
    echo "sed -e s/XXXX/$1/g -e s/XXCBTFXX/"$cbtfpwd"/g XXXX_tool.cpp > $1_tool.cpp"
    sed -e s/XXXX/$1/g -e s/XXCBTFXX/"$cbtfpwd"/g XXXX_tool.cpp > $1_tool.cpp
    rm XXXX_tool.cpp
  else
    echo "*** error can't find XXXX_tool.cpp"
  endif

  if ( -e "XXXXPlugin.cpp" ) then
    echo ""
    echo "sed -e s/XXXX/$1/g -e s/XXCBTFXX/"$cbtfpwd"/g XXXXPlugin.cpp > $1Plugin.cpp"
    sed -e s/XXXX/$1/g -e s/XXCBTFXX/"$cbtfpwd"/g XXXXPlugin.cpp > $1Plugin.cpp
    rm XXXXPlugin.cpp
  else
    echo "*** error can't find XXXXPlugin.cpp"
  endif

  if ( -e "XXXX.xml" ) then
    echo ""
    echo "sed -e s/XXXX/$1/g -e s/XXTOOL-PATHXX/"$mypwd"/g XXXX.xml > $1.xml"
    sed -e s/XXXX/$1/g -e s/XXTOOL-PATHXX/"$mypwd"/g XXXX.xml > $1.xml
    rm XXXX.xml
  else
    echo "*** error can't find XXXX.xml"
  endif
  
  echo ""
  echo "OK all your file names and content have been setup."
  echo "Now run: ./bootstrap"
  echo "Then run: sh -x myconfig"
  echo "Then run: make"
  echo "That will compile your code and give you an executable called $1"
  echo "If you edit your .cpp files you only need to rerun make, but if you add any files to the Makefile.am then rerun all the step." 
endif
